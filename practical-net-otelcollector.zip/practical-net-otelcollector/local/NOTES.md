

https://blog.knoldus.com/docker-manifest-a-peek-into-images-manifest-json-files/

https://www.aspecto.io/blog/opentelemetry-collector-guide/